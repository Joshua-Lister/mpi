var searchData=
[
  ['r_5fsplash_92',['r_splash',['../classalgorithm.html#aa8b466374555d102a3690fca5ceca7a5',1,'algorithm']]],
  ['recv_5fdata_93',['recv_data',['../classalgorithm.html#aea3a0c00ea6fe5ae6acc187a745b0735',1,'algorithm']]],
  ['requests_94',['requests',['../classalgorithm.html#af7d33e0f6b91bb07adff4801168c2d4b',1,'algorithm']]]
];
