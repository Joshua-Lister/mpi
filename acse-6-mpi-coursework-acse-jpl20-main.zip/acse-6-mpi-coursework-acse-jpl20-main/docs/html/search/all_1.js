var searchData=
[
  ['algorithm_1',['algorithm',['../classalgorithm.html',1,'algorithm'],['../classalgorithm.html#adcf3e23616eab2c8af21c3631e9cfbfd',1,'algorithm::algorithm()']]],
  ['apply_5fdirchlet_5fbc_2',['apply_dirchlet_bc',['../classalgorithm.html#a9d623f19a7f171289d9d4feaa20dee1c',1,'algorithm']]],
  ['apply_5fneumann_5fbc_3',['apply_neumann_bc',['../classalgorithm.html#a8046c46a263060a60b1411594188fe1b',1,'algorithm']]],
  ['acse_2d6_2dmpi_2dcoursework_2dacse_2djpl20_4',['acse-6-mpi-coursework-acse-jpl20',['../md_README.html',1,'']]]
];
