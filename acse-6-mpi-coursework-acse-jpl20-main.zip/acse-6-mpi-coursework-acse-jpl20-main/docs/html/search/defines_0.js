var searchData=
[
  ['_5fuse_5fmath_5fdefines_202',['_USE_MATH_DEFINES',['../algo_8cpp.html#a525335710b53cb064ca56b936120431e',1,'algo.cpp']]]
];
