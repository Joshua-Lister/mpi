var searchData=
[
  ['initial_5fcondition_64',['initial_condition',['../classalgorithm.html#a6a0445c2806826751547e3aae4c03272',1,'algorithm']]],
  ['interface_65',['interface',['../classinterface.html#a13e0ee4b9df1714d747d62ec46220c55',1,'interface']]]
];
