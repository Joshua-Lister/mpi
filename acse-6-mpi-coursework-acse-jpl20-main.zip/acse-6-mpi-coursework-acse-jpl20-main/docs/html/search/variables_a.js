var searchData=
[
  ['send_5fdata_95',['send_data',['../classalgorithm.html#ac5e2424866f3ed8737cbe34d8a5b3286',1,'algorithm']]]
];
