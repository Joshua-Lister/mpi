var searchData=
[
  ['send_5fdata_40',['send_data',['../classalgorithm.html#ac5e2424866f3ed8737cbe34d8a5b3286',1,'algorithm']]],
  ['setup_5fcontinuous_5farray_41',['setup_continuous_array',['../classalgorithm.html#ab294d43decef3e24843461c0f26bcacc',1,'algorithm']]],
  ['setup_5fdomain_42',['setup_domain',['../classalgorithm.html#a735f45eb6f4d571cf7087da3f0a696bc',1,'algorithm']]]
];
