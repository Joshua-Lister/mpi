var searchData=
[
  ['x_5fmax_49',['x_max',['../classalgorithm.html#af9cbc7eb84fd8666a554f34a3ad765f6',1,'algorithm::x_max()'],['../classinterface.html#ab1360a595cac7e527721f0e4ea957405',1,'interface::x_max()']]]
];
