var searchData=
[
  ['setup_5fcontinuous_5farray_69',['setup_continuous_array',['../classalgorithm.html#ab294d43decef3e24843461c0f26bcacc',1,'algorithm']]],
  ['setup_5fdomain_70',['setup_domain',['../classalgorithm.html#a735f45eb6f4d571cf7087da3f0a696bc',1,'algorithm']]]
];
