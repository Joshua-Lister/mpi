var searchData=
[
  ['old_5fgrid_89',['old_grid',['../classalgorithm.html#a485a732dfca16328e022545dcdac5326',1,'algorithm']]],
  ['out_5fcnt_90',['out_cnt',['../classalgorithm.html#a48a01dda097aaada85a1ecf3a42cc312',1,'algorithm']]]
];
