var searchData=
[
  ['n_28',['n',['../classalgorithm.html#a8eb3ca08b7af2084728742dec8e23ec9',1,'algorithm']]],
  ['neighbours_29',['neighbours',['../classalgorithm.html#a10e1f10602ca4d219f622861f4d3b7bf',1,'algorithm']]],
  ['new_5fgrid_30',['new_grid',['../classalgorithm.html#a6b1797d3ecd8818a29ac23046eeda91a',1,'algorithm']]]
];
