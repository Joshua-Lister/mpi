var searchData=
[
  ['calc_5fneighbours_56',['calc_neighbours',['../classalgorithm.html#a36818a70fc95e7c96208d57884ce7c1c',1,'algorithm']]],
  ['create_5fdatatypes_57',['create_datatypes',['../classalgorithm.html#a3146e177c3cb630edc5e07a2f16e7f1a',1,'algorithm']]]
];
