var searchData=
[
  ['algorithm_53',['algorithm',['../classalgorithm.html#adcf3e23616eab2c8af21c3631e9cfbfd',1,'algorithm']]],
  ['apply_5fdirchlet_5fbc_54',['apply_dirchlet_bc',['../classalgorithm.html#a9d623f19a7f171289d9d4feaa20dee1c',1,'algorithm']]],
  ['apply_5fneumann_5fbc_55',['apply_neumann_bc',['../classalgorithm.html#a8046c46a263060a60b1411594188fe1b',1,'algorithm']]]
];
