var searchData=
[
  ['boundary_5fcondition_73',['boundary_condition',['../classalgorithm.html#a2775859dd9b16b7e4caa63a3a6086bb9',1,'algorithm::boundary_condition()'],['../classinterface.html#ad851be3500356ed28246ea3f0e746a4e',1,'interface::boundary_condition()']]]
];
