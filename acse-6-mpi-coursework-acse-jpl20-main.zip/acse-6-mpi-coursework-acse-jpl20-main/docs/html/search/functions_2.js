var searchData=
[
  ['direction_58',['direction',['../classalgorithm.html#acda567b33ba2f51cb49d5f08f1178c5f',1,'algorithm']]],
  ['do_5fcomms_59',['do_comms',['../classalgorithm.html#a5e59ee231d07a93112eae50c40349b05',1,'algorithm']]],
  ['do_5finterior_5fiteration_60',['do_interior_iteration',['../classalgorithm.html#a036f76cdb2a5f1cfdd8ea1e0e006a9dc',1,'algorithm']]],
  ['do_5fiteration_5fext_5fperiodic_5fnon_5fperiodic_5fno_5fedge_61',['do_iteration_ext_periodic_non_periodic_no_edge',['../classalgorithm.html#a89ad190cf4d55936ec8d566348ae3f43',1,'algorithm']]]
];
