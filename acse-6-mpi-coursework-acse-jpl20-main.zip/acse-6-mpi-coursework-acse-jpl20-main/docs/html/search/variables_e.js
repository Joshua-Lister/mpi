var searchData=
[
  ['r_5fsplash_179',['r_splash',['../classalgorithm.html#aa8b466374555d102a3690fca5ceca7a5',1,'algorithm']]],
  ['recv_5fdata_180',['recv_data',['../classalgorithm.html#aea3a0c00ea6fe5ae6acc187a745b0735',1,'algorithm']]],
  ['requests_181',['requests',['../classalgorithm.html#af7d33e0f6b91bb07adff4801168c2d4b',1,'algorithm']]],
  ['right_5fghost_5ftype_182',['right_ghost_type',['../classalgorithm.html#a3bef63f292fa5afadd7408207dbd3617',1,'algorithm']]],
  ['right_5ftype_183',['right_type',['../classalgorithm.html#adf73272fca410174b9d2fc5a5b1111cd',1,'algorithm']]]
];
