var searchData=
[
  ['x_90',['x',['../namespaceprocessing.html#ab2e5681f2f87df082631df88944128f7',1,'processing']]],
  ['x_5fmax_91',['x_max',['../classalgorithm.html#af9cbc7eb84fd8666a554f34a3ad765f6',1,'algorithm::x_max()'],['../classinterface.html#ab1360a595cac7e527721f0e4ea957405',1,'interface::x_max()']]],
  ['x_5fsplash_92',['x_splash',['../classalgorithm.html#a4c5ceb20eaeff8cc95f0e5a2acc23a98',1,'algorithm']]],
  ['xmax_93',['xmax',['../namespaceprocessing.html#a2d887f220c5377c2950e8dc99b5395ed',1,'processing']]],
  ['xx_94',['xx',['../namespaceprocessing.html#a86fd92a2476745be637054a75f6cd216',1,'processing']]]
];
