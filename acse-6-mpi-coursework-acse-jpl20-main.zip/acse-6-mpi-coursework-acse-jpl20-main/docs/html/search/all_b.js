var searchData=
[
  ['r_5fsplash_34',['r_splash',['../classalgorithm.html#aa8b466374555d102a3690fca5ceca7a5',1,'algorithm']]],
  ['recv_5fdata_35',['recv_data',['../classalgorithm.html#aea3a0c00ea6fe5ae6acc187a745b0735',1,'algorithm']]],
  ['requests_36',['requests',['../classalgorithm.html#af7d33e0f6b91bb07adff4801168c2d4b',1,'algorithm']]],
  ['run_5fdirchlet_37',['run_dirchlet',['../classalgorithm.html#ad6e37ddf91c1fed7c87a30cb6331fc64',1,'algorithm']]],
  ['run_5fneumann_38',['run_neumann',['../classalgorithm.html#a37e6796a5ec11ae87e92765272834205',1,'algorithm']]],
  ['run_5fperiodic_39',['run_periodic',['../classalgorithm.html#a956dba7b3e73f5209335baf7dadaee84',1,'algorithm']]]
];
