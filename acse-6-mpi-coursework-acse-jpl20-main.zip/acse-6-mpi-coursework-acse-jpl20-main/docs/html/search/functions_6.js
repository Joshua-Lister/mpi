var searchData=
[
  ['run_5fdirchlet_66',['run_dirchlet',['../classalgorithm.html#ad6e37ddf91c1fed7c87a30cb6331fc64',1,'algorithm']]],
  ['run_5fneumann_67',['run_neumann',['../classalgorithm.html#a37e6796a5ec11ae87e92765272834205',1,'algorithm']]],
  ['run_5fperiodic_68',['run_periodic',['../classalgorithm.html#a956dba7b3e73f5209335baf7dadaee84',1,'algorithm']]]
];
